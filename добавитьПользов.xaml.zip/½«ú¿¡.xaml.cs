﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Maraphon
{
    /// <summary>
    /// Логика взаимодействия для логин.xaml
    /// </summary>
    public partial class логин : Page
    {
        public логин()
        {
            InitializeComponent();
        }
        private void Nazat_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new начало());
        }
        private void Cancel_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new начало());
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            логин1 contactsWindow = new логин1();
            contactsWindow.Owner = Window.GetWindow(this);
            contactsWindow.ShowDialog();
        }
    }
}
