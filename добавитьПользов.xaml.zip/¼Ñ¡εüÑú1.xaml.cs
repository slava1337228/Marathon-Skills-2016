﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Maraphon
{
    /// <summary>
    /// Логика взаимодействия для менюБег1.xaml
    /// </summary>
    public partial class менюБег1 : Page
    {
        public менюБег1()
        {
            InitializeComponent();
        }

        private void Nazat_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new начало());
        }

        private void logeout_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new начало());
        }

        private void regMarf_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new регистрация1());
        }

        private void MoiRez_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new моиРез());
        }

        private void kont_Click(object sender, RoutedEventArgs e)
        {
            контакты contactsWindow = new контакты();
            contactsWindow.Owner = Window.GetWindow(this);
            contactsWindow.ShowDialog();
        }

        private void redProf_Click(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new редПроф());
        }
        private void moiSpons(Object senter, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.MainFrame.Navigate(new моиСпонсоры());
        }
    }
}
